HELLO!

This is Tortus speaking. Thanks for downloading my tile editor! Hope it was worth the wait! This is the manual for the program. If you already know how to use it, go right on ahead. Otherwise, here's some pretty useful information:

P.S. the little label on the side that tells you which tile you are currently viewing is broken. Please be careful. 

**THE CONFIG FILE**
The config file is the central settings hub for the program. Do NOT move it. 
Inside, you will find a bunch of settings. Most of the settings will have this format: 
	setting_name:setting
Do not touch anything before the colon, as this will break the program. Only change the setting after the colon.
INPUT DIRECTORY:
 Make sure not to remove the dot! That dot stands for the current directory! If you remove it, then the file will only work in the home directory which is BAD.
OUTPUT DIRECTORY: currently broken. You can leave it blank ig
FILE NAME: the name of the file to be output
SIZE OF EDITOR: the size of the current editor window in pixels. 
PALETTE: input 16 hexadecimal numbers corresponding to the palette you want. 

TO USE: 
Left click to put a tile down on the editor, right click to remove the most recent tile. [>] moves you to the next metasprite. 
[<] moves you to the previous metasprite. 
[FlipX] and [FlipY] flip the most recent tile in the X and Y direction respectively. 
[P] sets the priority bit in the attributes. To select a palette, just click on it. 
[EXPORT] exports the file as in the config file. 
[RELOAD] reloads the panel.