jar cvmf META-INF/MANIFEST.MF Editor.jar *.class
